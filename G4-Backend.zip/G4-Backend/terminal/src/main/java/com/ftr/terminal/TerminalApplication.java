package com.ftr.terminal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TerminalApplication {

	public static void main(String[] args) {
		SpringApplication.run(TerminalApplication.class, args);
	}

}
