package com.ftr.terminal.controller;

import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ftr.terminal.dto.TerminalDTO;
import com.ftr.terminal.exception.TerminalException;
import com.ftr.terminal.service.TerminalService;

@RestController
@RequestMapping("/terminals")
public class TerminalController {

	@Autowired
	TerminalService service;
	
	@GetMapping
	public ResponseEntity<List<TerminalDTO>> fetchFTRTerminals() throws TerminalException {
		return ResponseEntity.ok(service.fetchFTRTerminals());
	}
	
	@GetMapping(path = "/fetchTerminalByTerminalId/{terminalId}")
	public ResponseEntity<TerminalDTO> fetchTerminalByTerminalId(@PathVariable String terminalId) throws TerminalException {
		return ResponseEntity.ok(service.fetchTerminalByTerminalId(terminalId));
	}
	
	@GetMapping(path = "/fetchTerminalByItemType/{itemType}")
	public ResponseEntity<List<TerminalDTO>> fetchTerminalsByItemType(@PathVariable String itemType) throws TerminalException {
		return ResponseEntity.ok(service.fetchTerminalsByItemType(itemType));
	}
	
	@PostMapping
	public ResponseEntity<TerminalDTO> insertNewTerminal(@Valid @RequestBody TerminalDTO terminalDTO, Errors error) throws TerminalException, MethodArgumentNotValidException {
		String response = "";
		if(error.hasErrors()) {
			response = error.getAllErrors().stream().map(ObjectError::getDefaultMessage).collect(Collectors.joining(", "));
			throw new TerminalException(response);
		}
		else {
			return ResponseEntity.ok(service.insertNewTerminal(terminalDTO));		
		}
	}
	
	@PutMapping(path = "/{terminalId}/{newCapacity}")
	public ResponseEntity<String> updateTerminal(@PathVariable String terminalId, @PathVariable int newCapacity) throws TerminalException {
		return ResponseEntity.ok(service.updateTerminal(terminalId, newCapacity));
	}
	
	@DeleteMapping(path = "/{terminalId}")
	public ResponseEntity<String> removeTerminal(@PathVariable String terminalId) throws TerminalException {
		return ResponseEntity.ok(service.removeTerminal(terminalId));
	}
}
