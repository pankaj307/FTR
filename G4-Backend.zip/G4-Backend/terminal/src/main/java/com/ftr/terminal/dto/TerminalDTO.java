package com.ftr.terminal.dto;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.ftr.terminal.entity.TerminalEntity;

public class TerminalDTO {
	
	private String terminalId;
	
	@NotBlank(message = "{termianl.terminalName.must}")
	@Size(min = 3, max = 20, message = "{terminal.terminalName.invalid}")
	private String terminalName;
	
	@NotBlank(message = "{termianl.country.must}")
	@Size(min = 3, max = 20, message = "{terminal.country.invalid}")
	private String country;

	@NotBlank(message = "{termianl.itemType.must}")
	@Size(min = 4, max = 30, message = "{terminal.itemType.invalid}")
	private String itemType;
	
	@NotBlank(message = "{termianl.terminalDescription.must}")
	@Pattern(regexp = "[T][0-9]+-[a-zA-Z ]*",message = "{terminal.terminalDescription.invalid}")
	@Size(max = 25, message = "{terminal.terminalDescriptionLength.invalid}")
	private String terminalDescription;
	
	@NotNull(message = "{terminal.capacity.must}")
	@Max(value = 99999, message="{terminal.capacity.invalid}")
	private int capacity;
	
	@NotBlank(message = "{terminal.status.must}")
	@Pattern(regexp = "(Available|Not Available|AVAILABLE|NOT AVAILABLE)", message = "{terminal.status.invalid}")
	private String status;
	
	@NotBlank(message = "{terminal.harborLocation.must}")
	@Size(min = 5, max = 25, message = "{terminal.harborLocationLength.invalid}")
	private String harborLocation;
	
	@NotNull(message = "{terminal.availableCapacity.must}")
	@Max(value = 99999, message="{terminal.availableCapacity.invalid}")
	private int availableCapacity;
	
	
	public String getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	public String getTerminalName() {
		return terminalName;
	}

	public void setTerminalName(String terminalName) {
		this.terminalName = terminalName;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	public String getTerminalDescription() {
		return terminalDescription;
	}

	public void setTerminalDescription(String terminalDescription) {
		this.terminalDescription = terminalDescription;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getHarborLocation() {
		return harborLocation;
	}

	public void setHarborLocation(String harborLocation) {
		this.harborLocation = harborLocation;
	}

	public int getAvailableCapacity() {
		return availableCapacity;
	}

	public void setAvailableCapacity(int availableCapacity) {
		this.availableCapacity = availableCapacity;
	}

	public static TerminalDTO EntityToDTO(TerminalEntity terminal) {
		TerminalDTO terminalDTO = new TerminalDTO();
		
		terminalDTO.setTerminalId(terminal.getTerminalId());
		terminalDTO.setTerminalName(terminal.getTerminalName());
		terminalDTO.setCountry(terminal.getCountry());
		terminalDTO.setItemType(terminal.getItemType());
		terminalDTO.setTerminalDescription(terminal.getTerminalDescription());
		terminalDTO.setCapacity(terminal.getCapacity());
		terminalDTO.setStatus(terminal.getStatus());
		terminalDTO.setHarborLocation(terminal.getHarborLocation());
		terminalDTO.setAvailableCapacity(terminal.getAvailableCapacity());
		
		return terminalDTO;
	}
	
	public static TerminalEntity DTOToEntity(TerminalDTO terminalDTO) {
		TerminalEntity terminalEntity = new TerminalEntity();
		
		terminalEntity.setTerminalId(terminalDTO.getTerminalId());
		terminalEntity.setTerminalName(terminalDTO.getTerminalName());
		terminalEntity.setCountry(terminalDTO.getCountry());
		terminalEntity.setItemType(terminalDTO.getItemType());
		terminalEntity.setTerminalDescription(terminalDTO.getTerminalDescription());
		terminalEntity.setCapacity(terminalDTO.getCapacity());
		terminalEntity.setStatus(terminalDTO.getStatus());
		terminalEntity.setHarborLocation(terminalDTO.getHarborLocation());
		terminalEntity.setAvailableCapacity(terminalDTO.getAvailableCapacity());
		
		return terminalEntity;
	}

}
