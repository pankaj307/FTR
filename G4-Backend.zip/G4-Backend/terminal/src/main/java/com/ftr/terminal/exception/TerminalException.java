package com.ftr.terminal.exception;

public class TerminalException extends Exception{
	public TerminalException(String msg) {
		super(msg);
	}
}
