package com.ftr.terminal.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ftr.terminal.entity.TerminalEntity;

public interface TerminalRepository extends JpaRepository<TerminalEntity, String>{
	TerminalEntity findByTerminalId(String terminalId);
}
