package com.ftr.terminal.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.ftr.terminal.dto.TerminalDTO;
import com.ftr.terminal.entity.TerminalEntity;
import com.ftr.terminal.exception.TerminalException;
import com.ftr.terminal.repository.TerminalRepository;

@Service
public class TerminalService {
	
	@Autowired
	TerminalRepository repo;
	
	@Autowired
	Environment env;

	public List<TerminalDTO> fetchFTRTerminals() throws TerminalException {
		List<TerminalEntity> allTerminals = repo.findAll();
		if(allTerminals != null && !allTerminals.isEmpty()) {
			List<TerminalDTO> dtoList = new ArrayList<>();
			for(TerminalEntity terminal : allTerminals) {
				TerminalDTO terminalDTO = TerminalDTO.EntityToDTO(terminal);
				dtoList.add(terminalDTO);
			}
			return dtoList;
		}
		throw new TerminalException(env.getProperty("terminal.empty"));
	}

	public TerminalDTO fetchTerminalByTerminalId(String terminalId) throws TerminalException {
		TerminalEntity terminal = repo.findByTerminalId(terminalId);
		if(terminal != null) {
			TerminalDTO dto = TerminalDTO.EntityToDTO(terminal);
			return dto;
		}
		throw new TerminalException(env.getProperty("terminal.notFound"));
	}

	public List<TerminalDTO> fetchTerminalsByItemType(String itemType) throws TerminalException {
		List<TerminalEntity> allTerminal = repo.findAll();
		if(allTerminal != null) {
			List<TerminalDTO> allDto = new ArrayList<>();
			for(TerminalEntity entity : allTerminal) {
				if(entity.getItemType().equals(itemType)) {
					TerminalDTO dto = TerminalDTO.EntityToDTO(entity);
					allDto.add(dto);
				}
			}
			if(allDto.size() != 0)
				return allDto;
			else
				throw new TerminalException(env.getProperty("terminal.itemtype.notFound"));
		}
		throw new TerminalException(env.getProperty("terminal.itemtype.notFound"));
	}

	public TerminalDTO insertNewTerminal(TerminalDTO terminalDTO) {
		long count = repo.count();
		count++;
		String terminalId = "T"+count;
		terminalDTO.setTerminalId(terminalId);
		TerminalEntity entity = TerminalDTO.DTOToEntity(terminalDTO);
		repo.save(entity);
		TerminalDTO dto = TerminalDTO.EntityToDTO(entity);
		return dto;
	}

	public String updateTerminal(String terminalId, int newCapacity) throws TerminalException {
		TerminalEntity terminalEntity = repo.findByTerminalId(terminalId);
		if(terminalEntity != null) {
			TerminalDTO terminalDTO = TerminalDTO.EntityToDTO(terminalEntity);
			int reducedCap = terminalDTO.getAvailableCapacity() - newCapacity;
			if(reducedCap < 0) {
				throw new TerminalException(env.getProperty("terminal.capacity.failed"));
			}
			terminalDTO.setAvailableCapacity(reducedCap);
			if(reducedCap == 0) {
				terminalDTO.setStatus("NOT AVAILABLE");
			}
			else {
				terminalDTO.setStatus("AVAILABLE");
			}
			repo.save(TerminalDTO.DTOToEntity(terminalDTO));
			return env.getProperty("terminal.update.success") + terminalId;
		}
		throw new TerminalException(env.getProperty("terminal.notFound"));
	}

	public String removeTerminal(String terminalId) throws TerminalException {
		TerminalEntity terminalEntity = repo.findByTerminalId(terminalId);
		if(terminalEntity != null) {
			repo.delete(terminalEntity);
			return env.getProperty("terminal.delete.success");
		}
		throw new TerminalException(env.getProperty("terminal.notFound")+terminalId);
	}

}
