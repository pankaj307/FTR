package com.ftr.user.controller;

import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ftr.user.dto.LoginDTO;
import com.ftr.user.dto.UserProfileDTO;
import com.ftr.user.dto.UserProfileUpdateDTO;
import com.ftr.user.exception.UserProfileException;
import com.ftr.user.service.UserProfileService;

@RestController
@RequestMapping(path = "/userProfile")
public class UserProfileController {

	@Autowired
	UserProfileService userProfileService;
	
	@PostMapping
	public ResponseEntity<UserProfileDTO> createUser(@Valid @RequestBody UserProfileDTO userProfileDTO, Errors error) throws UserProfileException, MethodArgumentNotValidException {
		String response = "";
		if(error.hasErrors()) {
			response = error.getAllErrors().stream().map(ObjectError::getDefaultMessage).collect(Collectors.joining(","));
			throw new UserProfileException(response);
		}
		else {
			return ResponseEntity.ok(userProfileService.createUser(userProfileDTO));			
		}
	}
	
	@PutMapping(path = "/{userId}")
	public ResponseEntity<String> updateUser(@PathVariable int userId, @Valid @RequestBody UserProfileUpdateDTO userProfileUpdteDTO, Errors error) throws UserProfileException {
		String response = "";
		if(error.hasErrors()) {
			response = error.getAllErrors().stream().map(ObjectError::getDefaultMessage).collect(Collectors.joining(","));
			throw new UserProfileException(response);
		}
		else {
			return ResponseEntity.ok(userProfileService.updateUser(userId, userProfileUpdteDTO));			
		}
	}
	
	@DeleteMapping(path = "/{userId}")
	public ResponseEntity<String> deleteUser(@PathVariable int userId) throws UserProfileException {
		return ResponseEntity.ok(userProfileService.deleteUser(userId));
	}
	
	@GetMapping(path = "/{userId}")
	public ResponseEntity<UserProfileDTO> getUser(@PathVariable int userId) throws UserProfileException {
		return ResponseEntity.ok(userProfileService.getUser(userId));
	}
	
	@PostMapping(path = "/login")
	public ResponseEntity<String> login(@RequestBody LoginDTO loginDTO) throws UserProfileException {
		return ResponseEntity.ok(userProfileService.login(loginDTO));
	}

}
