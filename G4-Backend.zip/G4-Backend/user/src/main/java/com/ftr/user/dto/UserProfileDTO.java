package com.ftr.user.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.ftr.user.entity.UserProfileEntity;

public class UserProfileDTO {

	private int userId;
	
	@NotBlank(message = "{user.firstName.must}")
	@Size(max = 20, message = "{user.firstName.invalid}")
	private String firstName;
	
	@NotBlank(message = "{user.lastName.must}")
	@Size(max = 20, message = "{user.lastName.invalid}")
	private String lastName;
	
	@NotBlank(message = "{user.email.must}")
	@Email(message = "{user.email.invalid}")
	private String emailId;
	
	@NotNull(message = "{user.phone.must}")
	@Min(value = 1000000000l, message="{user.phone.invalid}")
	@Max(value = 9999999999l, message="{user.phone.invalid}")
	private long mobileNumber;
	
	@NotBlank(message = "{user.password.must}")
	@Pattern(regexp = "(?=.*[-+_!@#$%^&*., ?]).+$", message = "{user.password.invalid}")
	@Size(min = 7, max = 15, message = "{user.password.invalidsize}")
	private String password;
	
	@NotBlank(message = "{user.nationality.must}")
	@Size(max = 20, message = "{user.nationality.invalid}")
	private String nationality;
	
	@NotBlank(message = "{user.passportNumber.must}")
	@Size(min = 7, max = 20, message = "{user.passportNumber.invalid}")
	private String passportNumber;
	
	@NotNull(message = "{user.permanentAddress.must}")
	@Size(max = 200, message = "{user.permanentAddress.invalid}")
	private String permanentAddress;
	
	@NotNull(message = "{user.officeAddress.must}")
	@Size(max = 200, message = "{user.officeAddress.invalid}")
	private String officeAddress;
	
	@NotNull(message = "{user.personalIdentificationNumber.must}")
	@Min(value = 100000000000l, message="{user.personalIdentificationNumber.invalid}")
	@Max(value = 999999999999l, message="{user.personalIdentificationNumber.invalid}")
	private long personalIdentificationNumber;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	public String getPermanentAddress() {
		return permanentAddress;
	}

	public void setPermanentAddress(String permanentAddress) {
		this.permanentAddress = permanentAddress;
	}

	public String getOfficeAddress() {
		return officeAddress;
	}

	public void setOfficeAddress(String officeAddress) {
		this.officeAddress = officeAddress;
	}

	public long getPersonalIdentificationNumber() {
		return personalIdentificationNumber;
	}

	public void setPersonalIdentificationNumber(long personalIdentificationNumber) {
		this.personalIdentificationNumber = personalIdentificationNumber;
	}

	public static UserProfileDTO userEntityToDTO(UserProfileEntity userProfileEntity) {
		UserProfileDTO userProfileDTO = new UserProfileDTO();
		
		userProfileDTO.setUserId(userProfileEntity.getUserId());
		userProfileDTO.setFirstName(userProfileEntity.getFirstName());
		userProfileDTO.setLastName(userProfileEntity.getLastName());
		userProfileDTO.setEmailId(userProfileEntity.getEmailId());
		userProfileDTO.setMobileNumber(userProfileEntity.getMobileNumber());
		userProfileDTO.setPassword(userProfileEntity.getPassword());
		userProfileDTO.setNationality(userProfileEntity.getNationality());
		userProfileDTO.setPassportNumber(userProfileEntity.getPassportNumber());
		userProfileDTO.setPermanentAddress(userProfileEntity.getPermanentAddress());
		userProfileDTO.setOfficeAddress(userProfileEntity.getOfficeAddress());
		userProfileDTO.setPersonalIdentificationNumber(userProfileEntity.getPersonalIdentificationNumber());
		
		return userProfileDTO;
	}

	public static UserProfileEntity userDTOToEntity(UserProfileDTO userProfileDTO) {
		UserProfileEntity userProfileEntity = new UserProfileEntity();
		
		userProfileEntity.setUserId(userProfileDTO.getUserId());
		userProfileEntity.setFirstName(userProfileDTO.getFirstName());
		userProfileEntity.setLastName(userProfileDTO.getLastName());
		userProfileEntity.setEmailId(userProfileDTO.getEmailId());
		userProfileEntity.setMobileNumber(userProfileDTO.getMobileNumber());
		userProfileEntity.setPassword(userProfileDTO.getPassword());
		userProfileEntity.setNationality(userProfileDTO.getNationality());
		userProfileEntity.setPassportNumber(userProfileDTO.getPassportNumber());
		userProfileEntity.setPermanentAddress(userProfileDTO.getPermanentAddress());
		userProfileEntity.setOfficeAddress(userProfileDTO.getOfficeAddress());
		userProfileEntity.setPersonalIdentificationNumber(userProfileDTO.getPersonalIdentificationNumber());
		
		return userProfileEntity;
	}

}
