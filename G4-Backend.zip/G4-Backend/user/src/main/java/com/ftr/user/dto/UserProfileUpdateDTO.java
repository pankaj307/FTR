package com.ftr.user.dto;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class UserProfileUpdateDTO {
	
	@NotNull(message = "{user.phone.must}")
	@Min(value = 1000000000l, message="{user.phone.invalid}")
	@Max(value = 9999999999l, message="{user.phone.invalid}")
	private long mobileNumber;
	
	@NotNull(message = "{user.permanentAddress.must}")
	@Size(max = 200, message = "{user.permanentAddress.invalid}")
	private String permanentAddress;
	
	@NotNull(message = "{user.officeAddress.must}")
	@Size(max = 200, message = "{user.officeAddress.invalid}")
	private String officeAddress;

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getPermanentAddress() {
		return permanentAddress;
	}

	public void setPermanentAddress(String permanentAddress) {
		this.permanentAddress = permanentAddress;
	}

	public String getOfficeAddress() {
		return officeAddress;
	}

	public void setOfficeAddress(String officeAddress) {
		this.officeAddress = officeAddress;
	}
	
	
}
