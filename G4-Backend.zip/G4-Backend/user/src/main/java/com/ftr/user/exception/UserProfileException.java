package com.ftr.user.exception;

public class UserProfileException extends Exception {
	public UserProfileException(String msg) {
		super(msg);
	}
}
