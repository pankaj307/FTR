package com.ftr.user.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class UserProfileExceptionHandler {
	@ExceptionHandler
	public ResponseEntity<UserErrorMessage> exceptionHandler(UserProfileException e){
		UserErrorMessage error = new UserErrorMessage();
		error.setErrorCode(HttpStatus.BAD_REQUEST.value());
		error.setErrorMsg(e.getMessage());
		return new ResponseEntity(error, HttpStatus.BAD_REQUEST);
	}
}
