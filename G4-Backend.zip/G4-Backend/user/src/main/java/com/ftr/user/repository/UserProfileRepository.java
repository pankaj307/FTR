package com.ftr.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ftr.user.entity.UserProfileEntity;

public interface UserProfileRepository extends JpaRepository<UserProfileEntity, Integer> {
	List<UserProfileEntity> findByPersonalIdentificationNumber(Long personalIdentificationNumber);
	UserProfileEntity findByUserId(int userId);
	void deleteByUserId(int userId);
}
