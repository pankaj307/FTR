package com.ftr.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.ftr.user.dto.LoginDTO;
import com.ftr.user.dto.UserProfileDTO;
import com.ftr.user.dto.UserProfileUpdateDTO;
import com.ftr.user.entity.UserProfileEntity;
import com.ftr.user.exception.UserProfileException;
import com.ftr.user.repository.UserProfileRepository;

@Service
public class UserProfileService {
	
	@Autowired
	UserProfileRepository userProfileRepository;
	
	@Autowired
	private Environment env;

	public UserProfileDTO createUser(UserProfileDTO userProfileDTO) throws UserProfileException {
		
		if (! userProfileRepository.findByPersonalIdentificationNumber(userProfileDTO.getPersonalIdentificationNumber()).isEmpty())
			throw new UserProfileException(env.getProperty("user.alreadyexists"));
		int userId = (int) userProfileRepository.count();
		userId += 10001;
		userProfileDTO.setUserId(userId);
		UserProfileEntity userProfileEntity = UserProfileDTO.userDTOToEntity(userProfileDTO);
		userProfileRepository.saveAndFlush(userProfileEntity);
		return UserProfileDTO.userEntityToDTO(userProfileEntity);
	}

	public String updateUser(int userId, UserProfileUpdateDTO userProfileUpdateDTO) throws UserProfileException {
		UserProfileEntity userProfile = userProfileRepository.findByUserId(userId);
		UserProfileEntity userProfileEntity;
		if(userProfile != null) {
			UserProfileDTO userProfileDTO = new UserProfileDTO();
			
			userProfileDTO.setUserId(userId);
			userProfileDTO.setFirstName(userProfile.getFirstName());
			userProfileDTO.setLastName(userProfile.getLastName());
			userProfileDTO.setEmailId(userProfile.getEmailId());
			
			userProfileDTO.setMobileNumber(userProfileUpdateDTO.getMobileNumber());
			
			userProfileDTO.setPassword(userProfile.getPassword());
			userProfileDTO.setNationality(userProfile.getNationality());
			userProfileDTO.setPassportNumber(userProfile.getPassportNumber());
			
			userProfileDTO.setPermanentAddress(userProfileUpdateDTO.getPermanentAddress());
			userProfileDTO.setOfficeAddress(userProfileUpdateDTO.getOfficeAddress());
			
			userProfileDTO.setPersonalIdentificationNumber(userProfile.getPersonalIdentificationNumber());
			
			userProfileEntity = UserProfileDTO.userDTOToEntity(userProfileDTO);
			userProfileEntity = userProfileRepository.save(userProfileEntity);
			return env.getProperty("user.update.success") + userId;
		}
		else
			throw new UserProfileException(env.getProperty("user.notFound"));
	}

	public String deleteUser(int userId) throws UserProfileException {
		UserProfileEntity user = userProfileRepository.findByUserId(userId);
		if(user != null) {
			userProfileRepository.deleteById(userId);
			return env.getProperty("user.delete.success") + userId;
		}
		else
			throw new UserProfileException(env.getProperty("user.notFound"));
	}

	public UserProfileDTO getUser(int userId) throws UserProfileException {
		UserProfileEntity user = userProfileRepository.findByUserId(userId);
		if(user != null) {
			return UserProfileDTO.userEntityToDTO(user);
		}
		else
			throw new UserProfileException(env.getProperty("user.notFound"));
	}

	public String login(LoginDTO loginDTO) throws UserProfileException {
		UserProfileEntity user = userProfileRepository.findByUserId(loginDTO.getUserId());
		if(user != null) {
			if(user.getPassword().equals(loginDTO.getPassword()))
				return env.getProperty("user.login.success");
			else
				throw new UserProfileException(env.getProperty("user.login.failure"));
		}
		else
			throw new UserProfileException(env.getProperty("user.login.failure"));
	}

}
