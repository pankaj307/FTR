package com.ftr.vehicle.controller;

import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ftr.vehicle.dto.VehicleDTO;
import com.ftr.vehicle.exception.VehicleException;
import com.ftr.vehicle.service.VehicleService;

@RestController
@RequestMapping("/vehicles")
public class VehicleController {

	@Autowired
	private VehicleService service;
	
	@PostMapping
	public ResponseEntity<String> insertNewVehicle(@Valid @RequestBody VehicleDTO dto, Errors error) throws VehicleException{
		String response = "";
		if(error.hasErrors()) {
			response = error.getAllErrors().stream().map(ObjectError::getDefaultMessage).collect(Collectors.joining(", "));
			throw new VehicleException(response);
		}
		response = service.insertNewVehicle(dto);
		return ResponseEntity.ok(response);
	}
		
//	@GetMapping
//	public ResponseEntity<List<VehicleDTO>> fetchAvailableVehicles() throws VehicleFtrException, VehicleNotFoundException {
//		logger.info("Controller -> fetchAvailableVehicles");
//		return ResponseEntity.ok(vehicleService.fetchAvailableVehicles());
//	}
//	
//	@GetMapping(value = "/managed-name/{vehicleName}")
//	public 	ResponseEntity<List<VehicleDTO>> fetchVehicleDetailsByVehicleName(@PathVariable("vehicleName") String vehicleName) throws VehicleFtrException, VehicleNotFoundException {
//		logger.info("Controller -> fetchVehicleDetailsByVehicleName");
//		return ResponseEntity.ok(vehicleService.fetchVehicleDetailsByVehicleName(vehicleName));
//	}
//	
//	@GetMapping(value = "/managed-number/{vehicleNumber}")
//	public ResponseEntity<VehicleDTO> fetchVehicleDetailsByVehicleNumber(@PathVariable("vehicleNumber") String vehicleNumber) throws VehicleFtrException, VehicleNotFoundException {
//		logger.info("Controller -> fetchVehicleDetailsByVehicleNumber");
//		return ResponseEntity.ok(vehicleService.fetchVehicleDetailsByVehicleNumber(vehicleNumber));
//	}
//	
//	@PutMapping(value = "/{vehicleNumber}")
//	public ResponseEntity<Message> updateVehicleStatus(@PathVariable("vehicleNumber") String vehicleNum, @RequestBody VehicleDTO dto) throws VehicleNotFoundException, VehichleStatusExistException {
//		logger.info("Controller -> updateVehicleStatus");
//		return ResponseEntity.ok(new Message(vehicleService.updateVehicleStatus(vehicleNum, dto)));
//	}
//	
//	@DeleteMapping(value = "/{vehicleNumber}")
//	public ResponseEntity<Message> removeVehicle(@PathVariable("vehicleNumber") String vehicleNum) throws Exception {
//		logger.info("Controller -> removeVehicle");
//		return ResponseEntity.ok(new Message(vehicleService.removeVehicle(vehicleNum)));
//	}
//	
//	
//	@GetMapping(value = "/harbor/{harborLocation}")
//	public ResponseEntity<List<VehicleDTO>> fetchVehicleByHarbor(@PathVariable("harborLocation") String harborLocation) throws VehicleNotFoundException{
//		logger.info("Controller -> fetchVehicleByHarbor");
//		return ResponseEntity.ok(vehicleService.fetchVehicleByHarbor(harborLocation));
//	}
}
