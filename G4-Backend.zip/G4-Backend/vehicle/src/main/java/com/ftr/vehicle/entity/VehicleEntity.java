package com.ftr.vehicle.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ftr_vehicle")
public class VehicleEntity {
	
	@Id
	@Column(name="vehicle_number")
	private String vehicleNumber;
	
	@Column(name="vehicle_name")
	private String vehicleName;
	
	@Column(name="max_lifting_capacity")
	private int maxLiftingCapacity;
	
	@Column(name="retire_date")
	private Date retireDate;
	
	@Column(name="vehicle_status")
	private String vehicleStatus;
	
	@Column(name="country")
	private String country;
	
	@Column(name = "harbor_location")
	private String harborLocation;
	
	public VehicleEntity() {
		
	}

	public VehicleEntity(String vehicleNumber, String vehicleName, int maxLiftingCapacity, Date retireDate,
			String vehicleStatus, String country, String harborLocation) {
		super();
		this.vehicleNumber = vehicleNumber;
		this.vehicleName = vehicleName;
		this.maxLiftingCapacity = maxLiftingCapacity;
		this.retireDate = retireDate;
		this.vehicleStatus = vehicleStatus;
		this.country = country;
		this.harborLocation = harborLocation;
	}

	public String getVehicleNumber() {
		return vehicleNumber;
	}

	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}

	public String getVehicleName() {
		return vehicleName;
	}

	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}

	public int getMaxLiftingCapacity() {
		return maxLiftingCapacity;
	}

	public void setMaxLiftingCapacity(int maxLiftingCapacity) {
		this.maxLiftingCapacity = maxLiftingCapacity;
	}

	public Date getRetireDate() {
		return retireDate;
	}

	public void setRetireDate(Date retireDate) {
		this.retireDate = retireDate;
	}

	public String getVehicleStatus() {
		return vehicleStatus;
	}

	public void setVehicleStatus(String vehicleStatus) {
		this.vehicleStatus = vehicleStatus;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getHarborLocation() {
		return harborLocation;
	}

	public void setHarborLocation(String harborLocation) {
		this.harborLocation = harborLocation;
	}
	
	
}
