package com.ftr.vehicle.exception;

public class VehicleException extends Exception{
	public VehicleException(String msg) {
		super(msg);
	}
}
