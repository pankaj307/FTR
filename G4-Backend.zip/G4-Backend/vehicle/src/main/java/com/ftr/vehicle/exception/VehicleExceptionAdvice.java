package com.ftr.vehicle.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class VehicleExceptionAdvice {

	@ExceptionHandler
	public ResponseEntity<VehicleErrorMessage> exceptionHandler(VehicleException e){
		VehicleErrorMessage error = new VehicleErrorMessage();
		error.setErrorCode(HttpStatus.BAD_REQUEST.value());
		error.setErrorMsg(e.getMessage());
		return new ResponseEntity(error, HttpStatus.BAD_REQUEST);
	}
}
