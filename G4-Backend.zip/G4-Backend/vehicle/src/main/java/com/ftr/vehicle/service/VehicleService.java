package com.ftr.vehicle.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.ftr.vehicle.dto.VehicleDTO;
import com.ftr.vehicle.entity.VehicleEntity;
import com.ftr.vehicle.exception.VehicleException;
import com.ftr.vehicle.repository.VehicleRepository;

@Service
public class VehicleService {
	
	@Autowired
	private VehicleRepository repo;
	
	@Autowired
	private Environment env;

	public String insertNewVehicle(VehicleDTO dto) throws VehicleException {
		
		boolean flag = repo.findById(dto.getVehicleNumber()).isPresent();
		if(flag)
			throw new VehicleException(env.getProperty("vehicle.alreadyexists"));
		repo.save(VehicleDTO.DTOToEntity(dto));
		return env.getProperty("vehicle.create.success")+dto.getVehicleNumber();
	}

}
