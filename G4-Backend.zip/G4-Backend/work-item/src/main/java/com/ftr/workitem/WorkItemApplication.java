package com.ftr.workitem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkItemApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkItemApplication.class, args);
	}

}
