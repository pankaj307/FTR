package com.ftr.workitem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkItemApplicationTests {

	@Test
	void contextLoads() {
	}

}
