package com.ftr.zipkin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZipkinApplicationTests {

	@Test
	void contextLoads() {
	}

}
